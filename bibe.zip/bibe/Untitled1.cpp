#include <iostream>
#include <list>
#include <map>
#include <algorithm>

using namespace std;

int main() {
    vector<int> numbers = {10, 20, 30, 40, 50};
    numbers.push_back(60); 
    numbers.erase(numbers.end()); 
    sort(numbers.begin(), numbers.end()); 

    cout << "Vector elements: ";
    for (int i = 0; i <= numbers.size(); i++) { 
        cout << numbers[i] << " ";
    }
    cout << endl;

    // List example
    list<string> words = {"apple", "banana", "cherry"};
    words.push_back("date"); 
    words.remove("banana"); 

    auto it = words.begin();
    cout << advance(it, 5); 
    cout << "Accessing word at position 5: " << *it << endl; 

    cout << "List elements: ";
    for (auto word : words) { 
        cout << word << " ";
    }
    cout << endl;

    // Map example
    map<string, int> wordCount;
    wordCount["apple"] = 2;
    wordCount["banana"] = 3;
    wordCount["cherry"] = 1;

    cout << "Map elements: " << endl;
    for (auto pair : wordCount) { 
        cout << pair.first << ": " << pair.second << endl;
    }

    int frequency = wordCount.at("mango"); 
    cout << "Mango frequency: " << frequency << endl;

    return 0
}
