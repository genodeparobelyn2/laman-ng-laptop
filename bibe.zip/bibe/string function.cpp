#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

struct Student {
    string name;
    string email;
    int age;
};

class EnrollmentSystem {
private:
    vector<Student> students;

public:
    void displayMenu() const {
        cout << "==================== Enrollment Form ====================" << endl;
        cout << "1. Enroll Student" << endl;
        cout << "2. Display Enrolled Students" << endl;
        cout << "3. Exit" << endl;
        cout << "========================================================" << endl;
    }

    void enrollStudent() {
        Student newStudent;

        cout << "Enter Student Name: ";
        getline(cin, newStudent.name);

        cout << "Enter Student Email: ";
        getline(cin, newStudent.email);

        cout << "Enter Student Age: ";
        cin >> newStudent.age;
        cin.ignore(); // Clear the newline character from the input buffer

        if (!isValidStudent(newStudent)) {
            cout << "Error: All fields must be filled correctly." << endl;
            return;
        }

        // Convert name to lowercase
        transform(newStudent.name.begin(), newStudent.name.end(), newStudent.name.begin(), ::tolower);
        
        students.push_back(newStudent);

        // Display the enrollment details
        cout << "Enrollment Successful!" << endl;
        cout << "Full Name: " << newStudent.name << endl;
        cout << "Age: " << newStudent.age << endl;
    }

    void displayEnrolledStudents() const {
        if (students.empty()) {
            cout << "No students enrolled yet." << endl;
            return;
        }

        cout << "==================== Enrolled Students ====================" << endl;
        for (const auto& student : students) {
            cout << "Name: " << student.name << ", Email: " << student.email << ", Age: " << student.age << endl;
        }
        cout << "========================================================" << endl;
    }

private:
    bool isValidStudent(const Student& student) const {
        return !student.name.empty() && !student.email.empty() && student.age > 0;
    }
};

int main() {
    EnrollmentSystem system;
    int choice;

    while (true) {
        system.displayMenu();
        cout << "Select an option: ";
        cin >> choice;
        cin.ignore(); // Clear the newline character from the input buffer

        switch (choice) {
            case 1:
                system.enrollStudent();
                break;
            case 2:
                system.displayEnrolledStudents();
                break;
            case 3:
                cout << "Exiting the program." << endl;
                return 0;
            default:
                cout << "Error: Invalid option. Please try again." << endl;
        }
    }

    return 0;
}

